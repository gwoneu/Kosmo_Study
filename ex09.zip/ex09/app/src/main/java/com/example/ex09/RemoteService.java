package com.example.ex09;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface RemoteService {
    public static final String BASE_URL = "http://192.168.0.195:8080";

    @POST("/user/login")
    Call<Integer> login(@Body UserVO vo);
}
